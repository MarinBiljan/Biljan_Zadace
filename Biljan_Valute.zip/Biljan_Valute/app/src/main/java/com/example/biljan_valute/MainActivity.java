package com.example.biljan_valute;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    DecimalFormat format = new DecimalFormat("0.00");
    TextView euri, dolari, svic;
    EditText kune;
    Button pretvori;
    double kneur, knusd, knchf, vrijednostknint;
    String vrijednostkn;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        euri = (TextView)findViewById(R.id.eur);
        dolari = (TextView)findViewById(R.id.dolar);
        svic = (TextView)findViewById(R.id.chf);
        kune = (EditText) findViewById(R.id.vrijednostKN);
        pretvori = (Button) findViewById(R.id.button);
        pretvori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vrijednostkn = kune.getText().toString();
                vrijednostknint = Double.valueOf(vrijednostkn);
                kneur = vrijednostknint / 7.531;
                knusd = vrijednostknint / 7.018;
                knchf = vrijednostknint / 7.627;
                euri.setText("€ " + String.valueOf(format.format(kneur)));
                dolari.setText("$ " + String.valueOf(format.format(knusd)));
                svic.setText("CHF " + String.valueOf(format.format(knchf)));
            }
        });
    }
}